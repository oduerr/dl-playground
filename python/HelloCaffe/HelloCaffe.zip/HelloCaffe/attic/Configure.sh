LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/lib
PYTHONPATH="${PYTHONPATH}:/home/dueo/caffe/caffe/python"
export PYTHONPATH
printenv PYTHONPATH
PATH="${PATH}:/home/dueo/caffe/caffe/python"
export PATH
printenv PATH
echo "Set path for caffe"